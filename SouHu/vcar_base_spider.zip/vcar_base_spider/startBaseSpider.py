from scrapy import cmdline

cmdline.execute("scrapy crawl baseSpider".split())#userSpider是爬虫的标识名